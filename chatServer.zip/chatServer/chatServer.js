const express = require('express');
const app = express();
const http = require('http').Server(app);
const io = require('socket.io')(http, {
    cors: {
      origin: "*",
    },
  });

const port = process.env.PORT || 3000;


io.on("connection", (socket) =>{
  socket.on("gameStarted", () => {
    for (let [id, receiver] of io.of("/").sockets) {
      if(receiver.gameId === socket.gameId) {
        receiver.emit("gameStarted")
      }
    }
  })
  
  socket.on("gameEnded", () => {
    for (let [id, receiver] of io.of("/").sockets) {
      if(receiver.gameId === socket.gameId) {
        receiver.emit("gameEnded")
      }
    }
  })

  socket.on("joinedGame", () => {
    for (let [id, receiver] of io.of("/").sockets) {
      if(receiver.gameId === socket.gameId) {
        receiver.emit("joinedGame")
      }
    }
  })

  socket.on("createdSquad", () => {
    for (let [id, receiver] of io.of("/").sockets) {
      if(receiver.gameId === socket.gameId) {
        receiver.emit("createdSquad")
      }
    }
  })

  socket.on("joinedSquad", () => {
    for (let [id, receiver] of io.of("/").sockets) {
      if(receiver.gameId === socket.gameId && receiver.human === socket.human && receiver.squadId === socket.squadId) {
        receiver.emit("joinedSquad")
      }
    }
  })

  socket.on("globalMessage", (msg) => {
    for (let [id, receiver] of io.of("/").sockets) {
      if(receiver.gameId === socket.gameId) {
        receiver.emit("globalMessage", socket.username + ": " + msg)
      }
    }
  })

  socket.on("factionMessage", (msg) => {
    for (let [id, receiver] of io.of("/").sockets) {
      if(receiver.gameId === socket.gameId && receiver.human === socket.human) {
        receiver.emit("factionMessage", socket.username + ": " + msg)
      }
    }
  })

  socket.on("squadMessage", (msg) => {
    for (let [id, receiver] of io.of("/").sockets) {
      if(receiver.gameId === socket.gameId && receiver.human === socket.human && receiver.squadId === socket.squadId) {
        receiver.emit("squadMessage", socket.username + ": " + msg)
      }
    }
  })

  socket.on("kill", (biteCode) => {
    for (let [id, receiver] of io.of("/").sockets) {
      if(receiver.gameId === socket.gameId) {
        receiver.emit("kill", biteCode)
      }
    }
  })

  socket.on("checkIn", () => {
    for (let [id, receiver] of io.of("/").sockets) {
      if(receiver.gameId === socket.gameId && receiver.human === socket.human && receiver.squadId === socket.squadId) {
        receiver.emit("checkIn")
      }
    }
  })
});

io.use((socket, next) => {
  const gameId = socket.handshake.auth.gameId;
  const username = socket.handshake.auth.username;
  const human = socket.handshake.auth.human;
  const squadId = socket.handshake.auth.squadId;

  if (!gameId) {
    return next(new Error("invalid gameId"));
  }

  if(!username) {
    return next(new Error("invalid username"));
  }

  socket.gameId = gameId;
  socket.username = username;
  socket.human = human;
  socket.squadId = squadId;
  next();
});

http.listen(port, () => console.log(`Listening on port ${port}...`));
